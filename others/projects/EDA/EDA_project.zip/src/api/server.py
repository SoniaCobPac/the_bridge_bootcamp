from flask import Flask, request
import os
import sys
import pandas as pd 
import argparse
import json 

def route(steps):
    route = __file__
    for i in range(steps):
        route = os.path.dirname(route)
    sys.path.append(route)
    return route 


route(2)
from utils.folders_tb import read_json

app = Flask(__name__)   

@app.route("/") 
def home():
    return 'Welcome! If you are looking for the information about the API project "Relationship between temperature and air quality" please enter the endpoint "/give_me_id?password=" and enter the correct password.'
   
@app.route('/give_me_id', methods=['GET']) # "localhost:6060/give_me_id?password=H71525533"
def give_id():
    x = request.args['password']    
    if x == "H71525533":    
        df = pd.read_csv(route(3) + os.sep + "data" + os.sep + "cleaned_data" + os.sep + "final_df.csv", encoding="Latin1") 

        return json.dumps(json.loads(df.to_json())) #no me lee las ñ o las tildes

    else:
        return "Wrong password"

def main():
    print("---------STARTING PROCESS---------")    
    json_readed = read_json(route(1), "settings")
    # Json variables are loaded:
    DEBUG = json_readed["debug"]
    HOST = json_readed["host"]
    PORT_NUM = json_readed["port"]
    app.run(debug=DEBUG, host=HOST, port=PORT_NUM)



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-x", type=str, help="Required password", required=True)
    args = vars(parser.parse_args())
    x = args["x"] 
    if x == "8642":
        main()  
        app.run(host='127.0.0.1',port=os.getenv("PORT", 6060), debug=True)  
    else:
        print("Wrong password")   
    

