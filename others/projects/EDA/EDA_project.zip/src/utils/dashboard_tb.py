import streamlit as st
import os
import sys
import pandas as pd 
import webbrowser
from PIL import Image
import requests
import json
st.set_option('deprecation.showPyplotGlobalUse', False)


def route (steps):
    sep = os.sep
    route = __file__
    for i in range(steps):
        route = os.path.dirname(route)
    sys.path.append(route)
    return route

#.....................mis dataframes
def plot_dataframe(path, filename):
    """
    """
    df_writed = pd.read_csv(path + os.sep + filename, index_col=[0])
    options = st.selectbox("Filter by pollutants", ["All", "O3", "SO2", "NO2", "CO", "PM10"])
    if options == "All":
        return st.dataframe(df_writed)    
    else:
        df_writed = df_writed[df_writed["POLLUTANT"] == options]
        return st.dataframe(df_writed)




#-------------------------------------------dataframes-----------------------------------------------------

def get_data_from_df(df):
    
    selected_values = df.iloc[:10,:].values
    
    return str(selected_values)

@st.cache(suppress_st_warning=True)
def load_csv_df(uploaded_file):
    df = None
    if uploaded_file != None:
        df = pd.read_csv(uploaded_file, nrows=200)
    return df

@st.cache(suppress_st_warning=True)

def load_normal_csv(uploaded_file): # funcion para leer csv. Tengo que cargar esta función en mi archivo principal app
    df = None
    if uploaded_file != None:
        df = pd.read_csv(uploaded_file, nrows=200)
    return df

@st.cache(suppress_st_warning=True)
def load_csv_for_map(csv_path):
    if csv_path != None:
        df = pd.read_csv(csv_path, sep=';')
        df = df.rename(columns={'latidtud': 'lat', 'longitud': 'lon'})
    st.balloons()
    return df

#--------------------------------------------------------------------------------------