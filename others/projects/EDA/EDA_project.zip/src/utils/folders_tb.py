import json
import os

def read_json(path, filename):
    """
    This function reads a json file given its name as parameter
    """
    with open(path + os.sep + filename +".json", "r+") as outfile:
        json_readed = json.load(outfile)
        return json_readed

def convert_to_json(dataframe):
    """
    """
    result = dataframe.to_json(orient="split")
    parsed = json.loads(result)
    json.dumps(parsed, indent=4)  

def save_json(path, filename, my_json):
    """
    This functions saves a json file given its name as parameter....etc

    """
    json_data = (path + os.sep + "reports" + os.sep + filename + ".json")
    with open(f"{json_data}", 'a+', encoding="Latin1") as outfile:
        json.dump(my_json, outfile, indent=4)
    return "file saved as json"


# estoy usando esta?---------------------------------
def read_csv(filename):
    """
    To read the previously created dataframes.
    
    Param: The filename (str) on which the information is wanted.
    """
    try:
        filename_df = pd.read_csv(route() + sep + "data" + sep + "cleaned_data" + sep + filename + ".csv", sep=",")  
        return filename_df
    except:
        print("No file with such name has been found")