import pandas as pd 
import seaborn as sns
import squarify
import matplotlib.pyplot as plt


#--------------------------------------AIR GRAPHS------------------------------------------------

# Outliers by group
def outliers_total(dataframe, pollutant, pollutant1, pollutant2, pollutant3, pollutant4):
    """

    Param: Pollutant names as string
    """
    #data to plot divided by pollutant
    pollut = dataframe.loc[dataframe["POLLUTANT"] == pollutant]
    pollut1 = dataframe.loc[dataframe["POLLUTANT"] == pollutant1]
    pollut2 = dataframe.loc[dataframe["POLLUTANT"] == pollutant2]
    pollut3 = dataframe.loc[dataframe["POLLUTANT"] == pollutant3]
    pollut4 = dataframe.loc[dataframe["POLLUTANT"] == pollutant4]

    f, axes = plt.subplots(3, 2, figsize=(15,10), sharex=False)
    axes1 = sns.boxplot(pollut["VALUE"], color = "blue", ax = axes[0,0])
    axes2 = sns.boxplot(pollut1["VALUE"], color = "red", ax = axes[0,1])
    axes3 = sns.boxplot(pollut2["VALUE"], color = "grey", ax = axes[1,0])
    axes4 = sns.boxplot(pollut3["VALUE"], color = "green", ax = axes[1,1])
    axes5 = sns.boxplot(pollut4["VALUE"], color = "gold", ax = axes[2,0])

    #Labels
    axes1.set_title(f"{pollutant} CONCENTRATION (µg/m3)")
    axes2.set_title(f"{pollutant1} CONCENTRATION (µg/m3)")
    axes3.set_title(f"{pollutant2} CONCENTRATION (µg/m3)")
    axes4.set_title(f"{pollutant3} CONCENTRATION (µg/m3)")
    axes5.set_title(f"{pollutant4} CONCENTRATION (µg/m3)")

    axes1.set(xlabel=None)
    axes2.set(xlabel=None)
    axes3.set(xlabel=None)
    axes4.set(xlabel=None)
    axes5.set(xlabel=None)

    return plt.show()


def pollutant_evolution_all(dataframe, xaxis, yaxis, hue, style, pollutant):
    """
    """
    plt.figure(figsize=(10,7))
    sns.lineplot(data=dataframe, x=xaxis, y=yaxis, hue=hue, style=style, linewidth = 3)

    plt.ylabel(f"{pollutant} CONCENTRATION (µg/m3)")
    plt.legend(loc = "best")
    plt.title("GAS CONCENTRATION EVOLUTION")

    return plt.show()

def pollutant_evolution_one(dataframe, pollutant):
    """
    """
    plt.figure(figsize=(7,4))

    df = dataframe.groupby("YEAR")[pollutant].mean()  

    sns.lineplot(data=df, linewidth = 3)

    plt.ylabel(f"pollutant CONCENTRATION (µg/m3)")
    plt.title(f"pollutant CONCENTRATION EVOLUTION")

    plt.show()


def tree_map(dataframe, pollutant):
    """
    """
    plt.figure(figsize=(15,10))
    data = dataframe.groupby("REGION").sum()[pollutant].sort_values(ascending=False)[:11]
    colour = ["steelblue", "lightgreen", "purple", "lightblue", "darkblue"]

    squarify.plot(sizes=data.values, label=data.index, alpha=.6, text_kwargs={'fontsize':25}, color=colour)

    plt.axis('off')
    return plt.show()


#-------------------------------------TEMPERATURE GRAPHS----------------------------------------

def temp_plot(dataframe):
    """
    """
    plt.figure(figsize=(10,7))

    sns.kdeplot(data=dataframe.T, fill=True, common_norm=False, palette="icefire", alpha=.4, linewidth=0)

    plt.xlabel("MEAN TEMPERATURE (ºc)")

    return plt.show()  

def temp_single(dataframe_section):
    """
    """
    plt.figure(figsize=(8,5))

    sns.kdeplot(data=dataframe_section, fill=True, common_norm=False, linewidth=1)

    plt.xlabel("MEAN TEMPERATURE (ºc)")

    return plt.show()


def temp_country(dataframe):
    """
    """
    plt.figure(figsize=(20,8))
          
    sns.barplot(palette = 'Blues_d', data = dataframe, ci = None)

    return plt.show()


#-----------------------------------COMPARISON GRAPHS--------------------------------------------

def corr_dataframe(temp_data, air, pol1, pol2, pol3, pol4, pol5):
    """
    """
    df1 = air.loc[air["POLLUTANT"] == pol1]
    df2 = air.loc[air["POLLUTANT"] == pol2]
    df3 = air.loc[air["POLLUTANT"] == pol3]
    df4 = air.loc[air["POLLUTANT"] == pol4]
    df5 = air.loc[air["POLLUTANT"] == pol5]

    corr_df = pd.merge(temp_data, df1, on="REGION", how="outer")
    corr_df.rename(columns={"VALUE": pol1}, inplace=True)
    corr_df = pd.merge(corr_df, df2, on="REGION", how="outer")
    corr_df.rename(columns={"VALUE": pol2}, inplace=True)
    corr_df = pd.merge(corr_df, df3, on="REGION", how="outer")
    corr_df.rename(columns={"VALUE": pol3}, inplace=True)
    corr_df = pd.merge(corr_df, df4, on="REGION", how="outer")
    corr_df.rename(columns={"VALUE": pol4}, inplace=True)
    corr_df = pd.merge(corr_df, df5, on="REGION", how="outer")
    corr_df.rename(columns={"VALUE": pol5}, inplace=True)

    corr_df = corr_df.drop(columns=["YEAR_x", "YEAR_y"]) 
    return corr_df


def column_tendency(column, xlim):
    """
    Param:
    and a range
    """
    plt.figure(figsize=(10,5))
    sns.distplot(column, color="brown", bins=5)

    plt.xlim(xlim)
    plt.title("TENDENCY")

    return plt.show()