# funciones que creas de streamlit - dashboard (todas las funciones)
# app montaje del streamlit (structura limpia) - pasar las funciones a dashboard!

# -*- coding: utf-8 -*-
import streamlit as st
import os
import sys
import pandas as pd 
import webbrowser
from PIL import Image
import requests
import json
st.set_option('deprecation.showPyplotGlobalUse', False)

sep = os.sep
route = __file__
for i in range(2):
    route = os.path.dirname(route)
sys.path.append(route)

import utils.dashboard_tb as dash
import utils.visualization_tb as vis

from utils.folders_tb import read_csv

route = os.path.dirname(route)
sys.path.append(route)

import resources as res
    
menu = st.sidebar.selectbox('Menu:',
            options=["Welcome", "Introduction", "Data Dataframe", "Graphs", "Data Json"])

if menu == "Welcome":
    st.title("Relationship between temperature and air quality")
    st.write("Project description..etc.........")


if menu == "Introduction":
    st.title("Relationship between temperature and air quality")    #no sale centrado
    image = Image.open(route + sep + "resources" + sep + "madrid_air.jpeg")
    st.image (image,use_column_width=True)

    st.write("Project description..etc.........")
    
    st.write("Select a pollutant below to be directed to the European Environment Agency for more information about it")
    options = st.selectbox("Pollutant information", ["None", "O3", "SO2", "NO2", "CO", "PM10"])
    if options == "O3":
        webbrowser.open_new_tab("https://www.eea.europa.eu/publications/2-9167-057-X/page022.html")
    if options == "SO2":
        webbrowser.open_new_tab("https://www.eea.europa.eu/data-and-maps/indicators/eea-32-sulphur-dioxide-so2-emissions-1")
    if options == "NO2":
        webbrowser.open_new_tab("https://www.eea.europa.eu/themes/air/air-quality/resources/glossary/nitrogen-oxides")
    if options == "CO":
        webbrowser.open_new_tab("https://www.eea.europa.eu/publications/2-9167-057-X/page024.html")
    if options == "PM10":
        webbrowser.open_new_tab("https://ec.europa.eu/environment/air/quality/standards.htm")


if menu == "Data Dataframe":
    st.write("Dataframe description..etc.........")
    path = route + os.sep + "data" + os.sep + "cleaned_data"

    dash.plot_dataframe(path, "final_df.csv")



            #st.bar_chart(df_slider) # mostrar grafico de todo el dataframe
            #st.table(df_slider)
        
 
if menu == "Gas Concentration Graphs":

    st.write("Graphs description..etc.........")
    
    path = route + sep + "data" + sep + "cleaned_data" + sep + "air.csv"
    
    data = pd.read_csv(path, sep=",")
    st.pyplot(vis.pollutant_evolution_all(data, "YEAR", "VALUE", "POLLUTANT", "POLLUTANT", "GASES"))
    #https://plotly.com/python/plotly-express/

def menu_datos(df):
    st.subheader('Mapa:')
    dibujar_mapa(df)
    cargadores_por_distrito = df.groupby('DISTRITO')['Nº CARGADORES'].sum()
    st.subheader('Cargadores por distrito:')
    st.bar_chart(cargadores_por_distrito)






if menu == "Data Json": 
    url = "http://localhost:6060/give_me_id?password=H71525533"
    resp = requests.get(url).json()
    st.write(resp)

